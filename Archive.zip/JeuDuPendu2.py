import random

f =  open("Names.txt", "r")
prepare_list = f.read()

liste = prepare_list.split("\n")

secret = random.choice(liste)

table = []

for pendu in secret:
    table.append(pendu)
i = 1

table_secret = []

while i <= len(table):
    table_secret.append('?')
    i = i+1

print(table_secret)

score = 10
print(score)


z = 0

while z < len(table):
    guess_what = input("Ecris une lettre \n ")
    letterFound = False
    for letterIndex in range(0, len(table)):
        if guess_what == table[letterIndex]:
            table_secret[letterIndex] = guess_what
            letterFound = True
    if letterFound == True:
        print("Pas mal! Tu as trouvé une lettre!")
        print(table_secret)
        z = z + 1

    else:
        score = score - 1
        print("Non, c'est faux. Tu dois retenter l'exercice ! Il te reste ", score, " essais")
        if score <= 0 :
            print("Tu as perdu. Le mot à trouver était...Je sais plus lol")
            break

fin = "".join(table_secret)

print(fin)

if table == table_secret:
    print("Tu as fini par trouver le mot ! Bravo")
